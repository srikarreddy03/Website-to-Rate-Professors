from django.apps import AppConfig


class AdminportalsConfig(AppConfig):
    name = 'adminPortals'
